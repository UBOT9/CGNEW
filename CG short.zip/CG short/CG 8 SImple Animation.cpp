#include<iostream>
#include<conio.h>
#include<graphics.h>
#include<dos.h>
int main()
{
	int gd=0,gm,x=20,flag=0,y=200,uplimit=250;
	initgraph(&gd,&gm, NULL);
	while(!kbhit())
	{
		setcolor(4);
		line(0,400,679,400);
		if(flag==0)
		{
			y+=2;
			x+=1;
			if(y>=385)
			flag=1;
		}
		if(flag==1)
		{
			y-=2;
			x+=1;
			if(y<=uplimit)
			{
				uplimit+=20;
				flag=0;
			}
		}
		setcolor(15);
		fillellipse(x,y,15,15);
		delay(10);
		setfillstyle(5,10);
		fillellipse(x,y,15,15);
		cleardevice();
	}
	return 0;
}

